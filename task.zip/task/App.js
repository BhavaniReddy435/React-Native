
import React from 'react';  
import { View, Text, Button,StyleSheet,TextInput,FlatList,SafeAreaView,TouchableOpacity } from 'react-native';  
import {  createAppContainer } from 'react-navigation';  
import { createStackNavigator } from 'react-navigation-stack'; 
  

// You can import from local files


// or any pure javascript modules available in npm
import { Card } from 'react-native-paper';

 class HomeScreen extends React.Component {
constructor(props){
  super(props)
  this.state={
    username:"",
    password:""
  }
}
validate_field =()=> {
const {username , password}=this.state
if(username==""){
  alert("please fill user name")
  return false
}else if(password==""){
   alert("please fill password");
   return false
}else if(username != "hruday@gmail.com"){
   alert("please enter  valid email")
   return false
}else if(password != "hruday123"){
   alert("please enter  valid password")
 return false
}
return true
}

make_api_call=()=>{
  if(this.validate_field()){
 //   alert("success")
this.props.navigation.navigate("Profile")
  }
   
}

  render() {
    return (
      <View style={{width:"100% ",height:"100%",justifyContent:"center",alignSelf:"center",alignContent:"center",alignItems:"center"}}>
        <TextInput placeholder="Enter UserName" 
        onChangeText={(value)=>this.setState({username:value})}
        style={{width:"80%",height:"42",borderBottomWidth:1}}/>
         <TextInput placeholder="Enter Password" 
          onChangeText={(value)=>this.setState({password:value})}
         style={{width:"80%",height:"42",borderBottomWidth:1,marginTop:"5%"}}/>
         <View style={{marginTop:"10%",width:"80%"}}>
         <TouchableOpacity style={{borderWidth:1,height:42,width:"80%",justifyContent:"center",alignItems:"center",alignSelf:"center",textAlign:"center",borderRadius:40,backgroundColor:"black"}}
          onPress={() =>this.make_api_call()}
   //  onPress={() =>alert("hii")}
 //  onPress={() => this.props.navigation.navigate('ProfileScreen')} 
         >
        
<Text style={{color:"white"}}>Click here
</Text>

         </TouchableOpacity>
         </View>
      </View>
    );
  }
}


// class ProfileScreen extends React.Component {  
//   constructor(props){
//     super(props)
//   }
//     render() {  
//         return (  
//             <View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>  
//                 <Text>Profile Screen</Text>  
//             </View>  
//     );  
//     }  
// }  
  

const DATA = [
  {
"id":1,
"name":"test1",
"age" : "11",
"gender":"male",
"email" : "test1@gmail.com",
"phoneNo" : "9415346313"
},
{
"id" : 2,
"name":"test2",
"age" : "12",
"gender":"male",
"email" : "test2@gmail.com",
"phoneNo" : "9415346314"
},
{
"id":3,
"name":"test3",

"age" : "13",
"gender":"male",
"email" : "test3@gmail.com",
"phoneNo" : "9415346315"
},
{
"id":4,
"name":"test4",
"age" : "14",
"gender":"male",
"email" : "test4@gmail.com",
"phoneNo" : "9415346316"
},
{
"id":5,
"name":"test5",
"age" : "15",
"gender":"male",
"email" : "test5@gmail.com",
"phoneNo" : "9415346317"
},
{
"id":6,
"name":"test6",
"age" : "16",
"gender":"male",
"email" : "test6@gmail.com",
"phoneNo" : "9415346318"
},
];

function Item({ name,age,gender,email,phoneNo }) {
  return (
    <View style={styles.item}>
      <Text style={styles.title}>{name}</Text>
       <Text style={styles.title}>{age}</Text>
        <Text style={styles.title}>{gender}</Text>
         <Text style={styles.title}>{email}</Text>
          <Text style={styles.title}>{phoneNo}</Text>
    </View>
  );
}

 class ProfileScreen extends React.Component {
  render(){
return (
    <SafeAreaView style={styles.container}>
      <FlatList
        data={DATA}
        renderItem={({ item }) => <Item name={item.name}  age={item.age} gender={item.gender} email={item.email} phoneNo={item.phoneNo}/>}
        keyExtractor={item => item.id}
      />
    </SafeAreaView>
  );
  }
  
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    
  },
  item: {
    backgroundColor: '#f9c2ff',
    padding: 20,
    marginVertical: 8,
    marginHorizontal: 16,
  },
  title: {
    fontSize: 20,
  },
});




const AppNavigator = createStackNavigator(  
    {  
        Home: HomeScreen,  
        Profile: ProfileScreen  
    },  
    {  
        initialRouteName: "Home"  
    }  
);  
  
const AppContainer = createAppContainer(AppNavigator);  
export default class App extends React.Component {  
    render() {  
        return <AppContainer />;  
    }  
}  